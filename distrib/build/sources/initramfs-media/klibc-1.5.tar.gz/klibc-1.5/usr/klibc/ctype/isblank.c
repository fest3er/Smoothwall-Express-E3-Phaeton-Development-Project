#include "ctypefunc.h"
CTYPEFUNC(isblank)
