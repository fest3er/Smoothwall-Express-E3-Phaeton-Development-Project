#include "ctypefunc.h"
CTYPEFUNC(isxdigit)
