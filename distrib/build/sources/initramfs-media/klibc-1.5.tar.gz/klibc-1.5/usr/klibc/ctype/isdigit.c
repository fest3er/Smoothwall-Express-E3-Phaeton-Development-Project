#include "ctypefunc.h"
CTYPEFUNC(isdigit)
