#ifndef _BITSIZE
#define _BITSIZE 64
#endif
